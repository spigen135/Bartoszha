package pl.wsiz.kalkulatorbmi;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Result.class}, version = 1)
public abstract class BmrDatabase extends RoomDatabase {

  private static BmrDatabase INSTANCE;

  public static BmrDatabase getAppDatabase(Context context) {

    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
        BmrDatabase.class, "database.db")
        .allowMainThreadQueries()
        .fallbackToDestructiveMigration()
        .build();
    return INSTANCE;
  }

  public abstract ResultDAO resultDAO();
}
