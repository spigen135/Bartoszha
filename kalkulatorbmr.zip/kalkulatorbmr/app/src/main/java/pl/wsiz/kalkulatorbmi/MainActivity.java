package pl.wsiz.kalkulatorbmi;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
  private EditText Wzrost, Waga, Wiek, Imie;
  private CheckBox cbM, cbK;
  private TextView Wynik, zapisz;
  private Button wynikBtn, zapiszBtn, pokazBtn;
  private float wzrost, waga, wynik;
  private int wiek;

  BmrDatabase bmrDatabase;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    bmrDatabase = BmrDatabase.getAppDatabase(getApplicationContext());
    setListeners();
  }

  private void setListeners() {
    Wzrost = findViewById(R.id.etWzost);
    Waga = findViewById(R.id.etWaga);
    Wynik = findViewById(R.id.tvWynik);
    Wiek = findViewById(R.id.etWiek);
    Imie = findViewById(R.id.etImie);
    cbK = findViewById(R.id.cbWomen);
    cbM = findViewById(R.id.cbMen);
    wynikBtn = findViewById(R.id.btnWynik);
    zapiszBtn = findViewById(R.id.btnSave);
    pokazBtn = findViewById(R.id.btnShow);

    wynikBtn.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        obliczBMR();
      }
    });

    zapiszBtn.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        if (Imie.getText().toString().isEmpty()) {
          Toast.makeText(getApplicationContext(), "Wpisz imie", Toast.LENGTH_SHORT).show();
        } else {
          Result result = new Result();
          result.setName(Imie.getText().toString());
          result.setResult(wynik);
          bmrDatabase.resultDAO().insert(result);
        }
      }
    });

    pokazBtn.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        if (!bmrDatabase.resultDAO().getAllResults().isEmpty()) {
          Log.i("=el", bmrDatabase.resultDAO().getAllResults().get(0).name);
        } else {
          Log.d("=el", "db pusta");
        }
        Intent intent = new Intent(MainActivity.this, ResultsActivity.class);
        startActivity(intent);
      }
    });

    cbK.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (cbM.isChecked()) {
          cbM.setChecked(false);
          cbK.setChecked(true);
        }
      }
    });

    cbM.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (cbK.isChecked()) {
          cbK.setChecked(false);
          cbM.setChecked(true);
        }
      }
    });
  }

  private float getWaga() {
    return Float.parseFloat(Waga.getText().toString());
  }

  private float getWzrost() {
    return Float.parseFloat(Wzrost.getText().toString());
  }

  private int getWiek() {
    return Integer.parseInt(Wiek.getText().toString());
  }

  private boolean isMen() {
    return cbM.isChecked();
  }

  private boolean isSexChoosen() {
    return cbK.isChecked() || cbM.isChecked();
  }

  public void obliczBMR() {
    waga = getWaga();
    wzrost = getWzrost();
    wiek = getWiek();

    if (waga != 0 && wzrost != 0 && isSexChoosen()) {
      wynik = calculateBMR(waga, wzrost, wiek, isMen());
      getResult(wynik);
    } else {
      Toast.makeText(this, "Sprawdz wprowadzone dane", Toast.LENGTH_SHORT).show();
    }
  }

  private void getResult(float bmr) {
    String wynik = "BMR: Twoje zapotrzebowanie to: " + bmr + " kcal/dziennie";
    Wynik.setText(wynik);
    zapiszBtn.setVisibility(View.VISIBLE);
  }

  private float calculateBMR(float waga, float wzrost, int wiek, boolean men) {
    if (men) {
      return (9.99f * waga) + (6.25f * wzrost) - (4.92f * wiek) + 5;
    } else {
      return (9.99f * waga) + (6.25f * wzrost) - (4.92f * wiek) - 161;
    }
  }
}
